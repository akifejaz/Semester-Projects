/*
 * MIProject.cpp
 *
 * Created: 03/07/2021 1:57:34 PM
 * Author : Muzamil
 */ 



#include <avr/io.h>	//AVR IO header file
#include <avr/interrupt.h> //AVR Port pin definition
#define F_CPU 1000000UL //default CPU frequency
#include <util/delay.h>	//delay utility added so that delay functions can be used

volatile uint8_t i = 0;


int count = 1;               //First floor
int destination = 4;         // Last floor
int pinchangeinterupt = 0;
int extint1 = 0;

int OB_UP1 = 0, OB_UP2 = 0, OB_UP3 = 0, OB_UP4 = 0;              // Outsides Buttons UP 
int OB_DOWN5 = 0, OB_DOWN4 = 0, OB_DOWN3 = 0, OB_DOWN2 = 0;      // // Outsides Buttons UP 
int DirectionUP = 0; int DirectionDown = 0; int go = 0; int Stop;
int S1 =0, S2=0, S3=0,S4=0, S5=0;



void init(){
	
	DDRB = 0b11111100;    // MuX + 7 Seg
	DDRD = 0b11111111;    // up/down/stop LED's
	DDRC = 0b00011111;    //Cabin Panel Input
}


//-----------------FUNCTIONS -------------//
void Elevator_inside_button();
void Motor_Speed(int x);
void Seg7Display();
void Door_LED();
void door_Status();
void pinChangeIntruppt();
void timer0For2mnDelay();
void destination_Finder();
void CombinationsChecks();
void externalIntrupt();
void Move_Upward();
void Move_Downward();
//-------------------------------------------

int main(void)
{
	int temp;
		init();
	//PIN CHANGE Interrupt for Elevator Outside Buttons
/*	timer0For2mnDelay();
	pinChangeIntruppt();
	externalIntrupt();*/
	
		PCICR = 1<<PCIE0;
		PCMSK0 = (1<<PCINT1)|(1<<PCINT0);
		
		EIMSK = (1<<INT1) | (1<<INT0);
		EICRA = (1<<ISC11)|(1<<ISC01)|(1<<ISC00);
		
		TCNT2=0;
		TIMSK2 = (1<<TOIE2);
		sei();
		
		TCCR2A=0x00;
		TCCR2B=0x03;
		
		TCCR0A=(1<<COM0A1)|(1<<WGM00);
		TCCR0B=(1<<CS02)|(1<<CS00);
	
	while(1)
	{
		//PORTD |= (1<<3);     // Door LED /set-> Means Door Close
		//PORTD |= (1<<3);
		
		PORTD |= (1<<0);
		Elevator_inside_button();
		destination_Finder();   // Output spacified
		
		
		
		
		
		temp = count - destination;
	
		Motor_Speed(temp);
		
		PORTB = (i & (0b00001100));
	}
}

/*
void externalIntrupt(){
	
	EIMSK = 1<<INT0;
	EIFR = 1<<INTF0;
	EICRA = 1<<ISC01;
	sei();
}
void timer0For2mnDelay(){
	
	TCNT0=0;
	TCCR0A=0x00;
	TCCR0B=0x02;
	TIMSK0 |= (1<<TOIE0);
	sei();
	
}

void pinChangeIntruppt(){
	
	
	PCICR = 1<<PCIE0;
	PCMSK0 = (1<<PCINT1)|(1<<PCINT0);
	sei();
}*/

void Door_LED(){
	for (int i=0; i<10; i++)  // Door remians open for 10 seconds
	{
		PORTD = 1<<0;
		_delay_ms(500);
		PORTD = 0<<0;
		_delay_ms(500);
	}
}

void Move_Upward(){		//AntiClockwise Direction
	PORTD = (1<<1);
	PORTD = (1<<5)|(0<<7);
	//_delay_ms(5000);
	//PORTD = (0<<5)|(0<<7);
}

void Move_Downward(){		//Clockwise Direction
	PORTD = (1<<2);
	PORTD = (0<<5)|(1<<7);
	//_delay_ms(5000);
	//PORTD = (0<<5)|(0<<7);
}

void Stop_Motor(){
	PORTD = (1<<0);
	PORTD = (0<<5)|(0<<7);
	//_delay_ms(5000);
	//PORTD = (0<<5)|(0<<7);
}

void Seg7Display(){
	if (count == 1)
	{
		PORTB = 1<<4;
	}
	else if (count == 2)
	{
		PORTB = 1<<5;
	}
	else if (count == 3)
	{
		PORTB = (1<<4)|(1<<5);
	}
	else if (count == 4)
	{
		PORTB = 1<<6;
	}
	else if (count == 5)
	{
		PORTB = (1<<6)|(1<<4);
	}
}

void Elevator_inside_button(){
	
	if ((PINC & 0b00000001) == 0b00000001)
	{
		S1 = 1;
	}
	
	else if ((PINC & 0b00000010) == 0b00000010)
	{
		S2 = 2;
		
	}
	
	else if ((PINC & 0b00000100) == 0b00000100)
	{
		S3 = 3;
		
	}
	
	else if ((PINC & 0b00001000) == 0b00001000)
	{
		S4 = 4;
		
	}
	
	else if ((PINC & 0b00010000) == 0b00010000)
	{
		S5 = 5;
		
	}
}


void destination_Finder()
{
	if (OB_DOWN5 == 0 && OB_UP2 ==0 && OB_UP3 ==0 && OB_UP4 ==0)   // Move to Base/down side  When  no other button is pressedn
	{
		DirectionDown = 1;
	}

	else if (OB_UP1 ==0 && OB_DOWN4 ==0 && OB_DOWN3 ==0 && OB_DOWN2 ==0)  // uppper ,mn jany k liye
	{
		DirectionUP = 1;
	}
	
	//CombinationsChecks();
	if (DirectionUP==1)
	{
		//Move_Upward();
		if ((S2==1 || OB_UP2==1) && (S3==0 && OB_UP3==0) && (S4==0 && OB_UP4==0) && (S5==0 && OB_DOWN5==0))  //Move to 2nd Floor
		{
			destination=2;
		}

		else if ((S3==1 || OB_UP3==1) && (S4==0 && OB_UP4==0) && (S5==0 && OB_DOWN5==0))  //MOve to 3rd Floor
		{
			destination=3;
		}

		else if ((S4==1 || OB_UP4==1) && (S5==0 && OB_DOWN5==0))  // Move to 4th Floor
		{
			destination=4;
		}
		
		else if (S5==1 || OB_DOWN5==0)     // Move to 5th Floor
		{
			destination=5;
		}
	}

	else if (DirectionDown==1)
	{
		//Move_Downward();
		if ((S4==1 || OB_DOWN4==1) && (S3==0 && OB_DOWN3==0) && (S2==0 && OB_DOWN2==0) && (S1==0 && OB_UP1==0)) // Move to 4th Floor
		{
			destination=4;
		}

		else if ((S3==1 || OB_DOWN3==1) && (S2==0 && OB_DOWN2==0) && (S1==0 && OB_UP1==0))
		{
			destination=3;
		}

		else if ((S2==1 || OB_DOWN2==1) && (S1==0 && OB_UP1==0))
		{
			destination=2;
		}

		else if (S1==1 || OB_UP1==1)
		{
			destination=1;
		}
	}
	
	if(destination>count)
	{
		DirectionUP=1;
		DirectionDown=0;
	}

	if(destination<count)
	{
		DirectionUP=0;
		DirectionDown=1;
	}
}

/*
void CombinationsChecks(){
	
	if (DirectionUP==1)
	{
		//Move_Upward();
		if ((S2==1 || OB_UP2==1) && (S3==0 && OB_UP3==0) && (S4==0 && OB_UP4==0) && (S5==0 && OB_DOWN5==0))  //Move to 2nd Floor
		{
			destination=2;
		}

		else if ((S3==1 || OB_UP3==1) && (S4==0 && OB_UP4==0) && (S5==0 && OB_DOWN5==0))  //MOve to 3rd Floor
		{
			destination=3;
		}

		else if ((S4==1 || OB_UP4==1) && (S5==0 && OB_DOWN5==0))  // Move to 4th Floor
		{
			destination=4;
		}
		
		else if (S5==1 || OB_DOWN5==0)     // Move to 5th Floor
		{
			destination=5;
		}
	}

	else if (DirectionDown==1)
	{
		//Move_Downward();
		if ((S4==1 || OB_DOWN4==1) && (S3==0 && OB_DOWN3==0) && (S2==0 && OB_DOWN2==0) && (S1==0 && OB_UP1==0)) // Move to 4th Floor
		{
			destination=4;
		}

		else if ((S3==1 || OB_DOWN3==1) && (S2==0 && OB_DOWN2==0) && (S1==0 && OB_UP1==0))
		{
			destination=3;
		}

		else if ((S2==1 || OB_DOWN2==1) && (S1==0 && OB_UP1==0))
		{
			destination=2;
		}

		else if (S1==1 || OB_UP1==1)
		{
			destination=1;
		}
	}

}*/

void door_Status()
{
	if(DirectionUP==1)
	{
		if(((OB_UP2==1) || (S2==1) || (Stop==1))  && (count==2))
		{
			//PORTD &= ~(1<<PD_1);
			//PORTC |= (1<<6);
			Door_LED();
			OB_UP2=0;
			S2=0;
		}

		else if(((OB_UP3==1) || (S3==1) || (Stop==1))  && (count==3))
		{
			//PORTB &= ~(1<<PB_4);
			Door_LED();
			OB_UP3=0;
			S3=0;
		}

		else if(((OB_UP4==1) || (S4==1) || (Stop==1))  && (count==4))
		{
			//PORTB &= ~(1<<PB_5);
			Door_LED();
			OB_UP4=0;
			S4=0;
		}

		else if(((OB_DOWN5==1) || (S5==1) || (Stop==1))  && (count==5))
		{
			//PORTB &= ~(1<<PB_6);
			Door_LED();
			OB_DOWN5=0;
			S5=0;
		}
	}

	if(DirectionDown==1)
	{
		if(((OB_UP1==1) || (S1==1) || (Stop==1))  && (count==1))
		{
	

			Door_LED();
			OB_UP1=0;
			S1=0;
			S2=0;
			S3=0;
			S4=0;
			S5=0;
			
		}

		else if(((OB_DOWN2==1) ||  (S2==1) || (Stop==1))  && (count==2))
		{
			//PORTC &= ~(1<<6);
			//PORTD &= ~(1<<PD_1);
			
			Door_LED();
			OB_DOWN2=0;
			S2=0;
		}

		else if(((OB_DOWN3==1) ||   (S3==1) || (Stop==1))  && (count==3))
		{
			//PORTB &= ~(1<<PB_4);
			
			Door_LED();
			OB_DOWN3=0;
			S3=0;
		}

		else if(((OB_DOWN4==1) ||  (S4==1) || (Stop==1))  && (count==4))
		{
			//PORTB &= ~(1<<PB_5);
			
			Door_LED();
			OB_DOWN4=0;
			S4=0;
		}
	}
}


void Motor_Speed(int x){
	
	/*if (count < destination)
	{
		Move_Upward();
	}
	else if (count > destination)
	{
		Move_Downward();
	}
	else if (count == destination)
	{
		Stop_Motor();
	}*/
	
	
	if (x == 0)
	{
		OCR0A=0x00;  // 0% Duty Cycle
		Stop_Motor();
	}
	if (x == 1)
	{
		OCR0A=0x40;  // 25% Duty Cycle
		Move_Downward();
	}
	if (x==2)
	{
		OCR0A=0x80;  // 50% Duty Cycle
		Move_Downward();
	}
	if (x==3)
	{
		OCR0A=0xC0;  // 75% Duty Cycle
		Move_Downward();
	}
	if (x==4)
	{
		OCR0A=0xFF;  // 100% Duty Cycle
		Move_Downward();
	}
	if (x == -1)
	{
		OCR0A=0x40;  // 25% Duty Cycle
		Move_Upward();
	}
	if (x == -2)
	{
		OCR0A=0x80;  // 50% Duty Cycle
		Move_Upward();
	}
	if (x == -3)
	{
		OCR0A=0xC0;  // 75% Duty Cycle
		Move_Upward();
	}
	if (x == -4)
	{
		OCR0A=0xFF;  // 100% Duty Cycle
		Move_Upward();
	}
}

ISR (TIMER2_OVF_vect)
{
	i++;
}


ISR(PCINT0_vect)
{
	
	if((PINB & 0b00000001)==1)
	{
		
		if(((i & (0b00001100))>>2)==0) // It means Down5 is pressed.
		{
			
			OB_DOWN5 = 1; 
			
		}

		else if(((i & (0b00001100))>>2)==1)	// It means Down4 is pressed.
		{
			OB_DOWN4 = 1;

		}

		else if(((i & (0b00001100))>>2)==2)	// It means Down3 is pressed.
		{
			
			OB_DOWN3 = 1;
		
		}

		else if(((i & (0b00001100))>>2)==3)	// It means Down2 is pressed.
		{
			OB_DOWN4 = 1;
		
		}
	}

	if((PINB & 0b00000010)==2)
	{

		if(((i & (0b00001100))>>2)==0)	// It means Up4 is pressed.
		{
			
			OB_UP4 = 1;
		}

		else if(((i & (0b00001100))>>2)==1)	// It means Up3 is pressed.
		{
			OB_UP3 = 1;
		}

		else if(((i & (0b00001100))>>2)==2)	// It means Up2 is pressed.
		{
			OB_UP2 = 1;
		}

		else if(((i & (0b00001100))>>2)==3)	// It means Up1 is pressed.
		{
			OB_UP1 = 1;
		}
	}
}


ISR (INT1_vect){
		destination_Finder();
		
		if (count < destination)
		{
			DirectionUP=1;
			DirectionDown=0;
			
			//Move_Upward();
			
			if (count <5)
			{
				count++;
			}
			
			if (Stop == 1)
			{
				Seg7Display();
				door_Status();
				Stop = 0;
			}

			if (count==5)
			{
				Seg7Display();
				Door_LED();
				
				OB_DOWN5=0;
				DirectionDown=1;
				DirectionUP=0;
			}

			else if (count==2)
			{
				Seg7Display();
				door_Status();
			}

			else if (count==3)
			{
				Seg7Display();
				door_Status();
			}

			else if (count==4)
			{
				Seg7Display();
				door_Status();
			}
		}
		else if (count == destination)
		{
			if (Stop == 1)
			{
				Seg7Display();
				door_Status();
				Stop = 0;
			}

			if(count==1 && destination==1)
			{
				Seg7Display();
				door_Status();
				count=2;
				
				DirectionUP=1;
				DirectionDown=0;
			}

			else if(count==2 && destination==2)
			{
				Seg7Display();
				door_Status();
				//DirectionUP=0;
				//DirectionDown=0;
			}

			else if(count==3 && destination==3)
			{
				Seg7Display();
				door_Status();
			}

			else if(count==4 && destination==4)
			{
				Seg7Display();
				door_Status();
			}

			else if(count==5 && destination==5)
			{
				Seg7Display();
				door_Status();
				DirectionUP=0;
				DirectionDown=1;
			}
		}
		else if(count > destination) {
			
			//Lift is not reached on the Required/Destination Floor
			DirectionUP=0;
			DirectionDown=1;
			//Move_Downward();
			
			
			if (count>1)
			{
				count--;
			}
			if (Stop ==1)
			{
				Seg7Display();
				Door_LED();
				Stop = 0;
			}
			
			if (count==4)
			{
				Seg7Display();
				door_Status();
			}

			else if (count==3)
			{
				Seg7Display();
				door_Status();
			}

			else if (count==2)
			{
				Seg7Display();
				door_Status();
			}

			else if (count==1)
			{
				Seg7Display();
				door_Status();
				
				DirectionUP=1;
				DirectionDown=0;
			}
			
		}
		
		destination_Finder();
	
}

ISR (INT0_vect){
	Stop = 1;
}

























/*
#include <avr/io.h>	//AVR IO header file
#include <avr/interrupt.h> //AVR Port pin definition
#define F_CPU 1000000UL //default CPU frequency
#include <util/delay.h>	//delay utility added so that delay functions can be used

volatile uint8_t i = 0;


int count = 1; //Current floor
int destination = 5; // Last floor
int pinchangeinterupt = 0, UP1 = 0, UP2 = 0, UP3 = 0, UP4 = 0, DOWN5 = 0, DOWN4 = 0, DOWN3 = 0, DOWN2 = 0; 

void init(){
	DDRB = 0b11111100;
	DDRD = 0b11111111;
	DDRC = 0b00011111;
}

void Elevator_inside_button(){
	if ((PINC & 0b00000001) == 0b00000001)
	{
		destination = 1;
	}
	
	else if ((PINC & 0b00000010) == 0b00000010)
	{
		destination = 2;
	
	}
	
	else if ((PINC & 0b00000100) == 0b00000100)
	{
		destination = 3;
		
	}
	
	else if ((PINC & 0b00001000) == 0b00001000)
	{
		destination = 4;
	
	}
	
	else if ((PINC & 0b00010000) == 0b00010000)
	{
		destination = 5;
	
	}
}


void Move_Upward(){		//AntiClockwise Direction
	PORTD = (1<<1);
	PORTD = (1<<6)|(0<<7); 
	_delay_ms(5000);
	PORTD = (0<<6)|(0<<7);
}

void Move_Downward(){		//Clockwise Direction
	PORTD = (1<<2);
	PORTD = (0<<6)|(1<<7);
	_delay_ms(5000);
	PORTD = (0<<6)|(0<<7);
}

void Motor_Speed(int x){
	if (x==25)
	{
		OCR0A=0x40;  // 25% Duty Cycle
	}
	if (x==50)
	{
		OCR0A=0x80;  // 50% Duty Cycle
	}
	if (x==75)
	{
		OCR0A=0xC0;  // 75% Duty Cycle
	}
	if (x==100)
	{
		OCR0A=0xFF;  // 100% Duty Cycle
	}
}

void Seg7Display(){
	if (count == 1)
	{
		PORTB = 1<<4;
	}
	else if (count == 2)
	{
		PORTB = 1<<5;
	}
	else if (count == 3)
	{
		PORTB = (1<<4)|(1<<5);
	}
	else if (count == 4)
	{
		PORTB = 1<<6;
	}
	else if (count == 5)
	{
		PORTB = (1<<6)|(1<<4);
	}
}

void Doors_Open(){
	for (int i=0; i<10; i++)  // Door remians open for 10 seconds
	{
		PORTD = 1<<0;
		_delay_ms(500);
		PORTD = 0<<0;
		_delay_ms(500);
	}
	
}



int main(void)
{
	init();
	
	//PIN CHANGE Interrupt for Elevator Outside Buttons
	PCICR = 1<<PCIE0;
	
	PCMSK0 = (1<<PCINT1)|(1<<PCINT0);


	TCNT2=0;
	TIMSK2 |= (1<<TOIE2);
	TCCR2A=0x00;
	TCCR2B=0x04;

	sei();

	
	//FOR PWM, MOTOR SPEED 
	TCCR0A=(1<<COM0A1)|(1<<WGM00); // PWM Phase Corrected mode // Non Inverting Mode
	TCCR0B=(1<<CS02)|(1<<CS00); //Prescallar 1024
	
	
	
	if (count == 1)  // it means lift is on 1st floor.
	{
		//PORTB = (1<<3)|(1<<2);			// Selectlines A = 1 and B = 1
		Seg7Display();
	}
    
	

    while (1) 
    { 
			PORTB=(i&(0b00001100));
			
		
	
		
		
		Elevator_inside_button(); 
	
		if (destination - count == 1)
		{
			Move_Upward();	// moves motor with 25% duty cycle.
			count = 2;
			Seg7Display();
						
		}
		else if (destination - count == 2)
		{
			Move_Upward();	// moves motor with 50% duty cycle.
			count = 3;
			Seg7Display();
		}
		else if (destination - count == 3)
		{
			Move_Upward();	// moves motor with 75% duty cycle.	
			count = 4;
			Seg7Display();
		}
		else if (destination - count == 4)
		{
			Move_Upward();	// moves motor with 100% duty cycle.
			count = 5;
			Seg7Display();
		}
		
		else if (destination - count == -1)
		{
			Move_Downward();	// moves motor with 25% duty cycle.
			count = 4;
			Seg7Display();
			
		}
		else if (destination - count == -2)
		{
			Move_Downward();	// moves motor with 50% duty cycle.
			count = 3;
			Seg7Display();
			
		}
		else if (destination - count == -3)
		{
			Move_Downward();	// moves motor with 75% duty cycle.
			count = 2;
			Seg7Display();
		}
		else if (destination - count == -4)
		{
			Move_Downward();	// moves motor with 100% duty cycle.
			count = 1;
			Seg7Display();
		}
		
		
		if (pinchangeinterupt == 1)
		{
			if ((PINB & 0b00000001) == 0b00000001) //It means any of the 4 DOWN button is pressed.
			{
				if ((PINB & 0b00000000) == 0b00000000) //Selectlines A =0, B=0 // On the 5th floor DOWN button is pressed.
				{
					DOWN5 = 1;
				}
				if ((PINB & 0b00000100) == 0b00000100) //Selectlines A =1, B=0 // On the 4th floor DOWN button is pressed.
				{
					DOWN4 = 1;
				}
				if ((PINB & 0b00001000) == 0b00001000) //Selectlines A =0, B=1 // On the 3rd floor DOWN button is pressed.
				{
					DOWN3 = 1;
				
				if ((PINB & 0b00001100) == 0b00001100)  // Selectlines A =1, B=1 // On the 2nd floor DOWN button is pressed.  
				{
					DOWN2 = 1;
				}
				
			}
			if ((PINB & 0b00000010) == 0b00000010) //It means any of the 4 UP button is pressed.
			{
				if ((PINB & 0b00001100) == 0b00001100) //Selectlines A =0, B=0 // On the 1st floor UP button is pressed.
				{
					UP1 = 1;
	
				}
				if ((PINB & 0b00000100) == 0b00000100) // //Selectlines A =1, B=0 // On the 2nd floor UP button is pressed.
				{
					UP2 = 1;
				}
				
				if ((PINB & 0b00001000) == 0b00001000) //Selectlines A =0, B=1 // On the 3rd floor UP button is pressed.
				{
					UP3 = 1;
				}
				if ((PINB & 0b00001100) == 0b00001100) // //Selectlines A =1, B=1 // On the 4th floor UP button is pressed.
				{
					UP4 = 1;
				}
				
			}
			
		} 
		
		if (UP1 == 1) // On the floor 1 the UP button is pressed.
		{
			Doors_Open();
			Move_Upward();
			Seg7Display();
		}
		if (UP1 == 1) // On the floor 2 the UP button is pressed.
		{
			Doors_Open();
			Move_Upward();
			Seg7Display();
		}
		if (UP1 == 1) // On the floor 3 the UP button is pressed.
		{
			Doors_Open();
			Move_Upward();
			Seg7Display();
		}
		if (UP1 == 1) // On the floor 4 the UP button is pressed.
		{
			Doors_Open();
			Move_Upward();
			Seg7Display();
		}
		
		
		if (DOWN2 == 1) // On the floor 2 the DOWN button is pressed.
		{
			Doors_Open();
			Move_Downward();
			Seg7Display();
		}
		if (DOWN3 == 1) // On the floor 2 the DOWN button is pressed.
		{
			Doors_Open();
			Move_Downward();
			Seg7Display();
		}
		if (DOWN4 == 1) // On the floor 4 the DOWN button is pressed.
		{
			Doors_Open();
			Move_Downward();
			Seg7Display();
		}
		if (DOWN5 == 1) // On the floor 5 the DOWN button is pressed.
		{
			Doors_Open();
			Move_Downward();
			Seg7Display();
		}
			
    }
}

ISR (TIMER2_OVF_vect)
{
	i++;
}


ISR(PCINT0_vect)
{
	if((PINB&0b00000001)==1)
	{
		if(((i&(0b00001100))>>2)==0) // It means Down5 is pressed.
		{
			DOWN5;
		}

		else if(((i&(0b00001100))>>2)==1)	// It means Down4 is pressed.
		{
			;
		}

		else if(((i&(0b00001100))>>2)==2)	// It means Down3 is pressed.
		{
			
		}

		else if(((i&(0b00001100))>>2)==3)	// It means Down2 is pressed.
		{
			
		}
	}

	if((PINB&0b00000010)==2)
	{
		if(((i&(0b00001100))>>2)==0)	// It means Up4 is pressed.
		{
			
		}

		else if(((i&(0b00001100))>>2)==1)	// It means Up3 is pressed.
		{
			
		}

		else if(((i&(0b00001100))>>2)==2)	// It means Up2 is pressed.
		{
			
		}

		else if(((i&(0b00001100))>>2)==3)	// It means Up1 is pressed.
		{
			
		}
	}
}

*/